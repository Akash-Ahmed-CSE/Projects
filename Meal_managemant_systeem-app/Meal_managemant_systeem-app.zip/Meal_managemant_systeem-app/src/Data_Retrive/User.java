package Data_Retrive;


public class User {
private int ID;
private String Name,Address,PhoneNo,ItemName,NumberOfItem;

public User(int ID,String Name,String Address,String PhoneNo,String ItemName,String NumberOfItem){
    this.ID=ID;
    this.Name= Name;
    this.Address=Address;
    this.PhoneNo=PhoneNo;
    this.ItemName=ItemName;
    this.NumberOfItem=NumberOfItem;
    
}
public int getID(){
    return ID;
    
} 
public String getName(){
    return Name;
}
public String getAddress(){
    return Address;
}
public String getPhoneNo(){
    return PhoneNo;
}
public String getItemName(){
    return ItemName;
}
public String getNumberOfItem(){
    return NumberOfItem;
}

}
